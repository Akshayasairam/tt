$(document).ready(function(){
  continueClick();
  goBack();
})

function continueClick(){
  $('#continue').on('click',function(){
    $(form).css('transform','translateX(0)')
    $('#step-2-container').css('opacity','1')
    $('#step-1-container').css('opacity','0')
    $('.fa-building-o').css('color', '#00aced')
    $('#step-2').css('color', '#00aced')
    $('#stop-1').attr('offset','100%')
    return false;
  })
}

function goBack(){
  $('#goback').on('click',function(){
    $(form).css('transform','translateX(-50%)')
    $('#step-2-container').css('opacity','0')
    $('#step-1-container').css('opacity','1')
    $('.fa-building-o').css('color', '#888')
    $('#step-2').css('color', '#888')
    $('#stop-1').attr('offset','0%')
  })
}