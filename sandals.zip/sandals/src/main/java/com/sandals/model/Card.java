package com.sandals.model;

public class Card {

	
	private String c_holdername;
	private int c_pin;
	private int c_expdate;
	private int c_ccv;
	
	
	public String getC_holdername() {
		return c_holdername;
	}
	public void setC_holdername(String c_holdername) {
		this.c_holdername = c_holdername;
	}
	public int getC_pin() {
		return c_pin;
	}
	public void setC_pin(int c_pin) {
		this.c_pin = c_pin;
	}
	public int getC_expdate() {
		return c_expdate;
	}
	public void setC_expdate(int c_expdate) {
		this.c_expdate = c_expdate;
	}
	public int getC_ccv() {
		return c_ccv;
	}
	public void setC_ccv(int c_ccv) {
		this.c_ccv = c_ccv;
	}
}
