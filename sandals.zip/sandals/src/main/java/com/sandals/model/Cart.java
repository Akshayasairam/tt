package com.sandals.model;

public class Cart {

	private Products prod;
	private int c_pid;
	private String c_pname;
	private double c_price;
	public Products getProd() {
		return prod;
	}
	public void setProd(Products prod) {
		this.prod = prod;
	}
	public int getC_pid() {
		return c_pid;
	}
	public void setC_pid(int c_pid) {
		this.c_pid = c_pid;
	}
	public String getC_pname() {
		return c_pname;
	}
	public void setC_pname(String c_pname) {
		this.c_pname = c_pname;
	}
	public double getC_price() {
		return c_price;
	}
	public void setC_price(double c_price) {
		this.c_price = c_price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	private int qty;
	public Cart (Products prod,int qty)
	{
		this.c_pid=prod.getProd_id();
		this.c_pname=prod.getProd_name();
		this.c_price=prod.getProd_price();
		this.qty=qty;
	}
}
