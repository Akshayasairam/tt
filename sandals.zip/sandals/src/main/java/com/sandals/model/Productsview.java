package com.sandals.model;

import java.util.ArrayList;
import java.util.List;

public class Productsview {
public List<String>  getList()
{
		
		List<String> list=new ArrayList<String>();
		
		list.add("Black buckles");
		list.add("Skinny heels");
		
		
		
		return list;
}
}
