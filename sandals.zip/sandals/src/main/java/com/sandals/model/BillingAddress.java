package com.sandals.model;



public class BillingAddress {

	private String bill_street1;

	private String bill_city;
	
	private String bill_state;
	
	public String getBill_street1() {
		return bill_street1;
	}

	public void setBill_street1(String bill_street1) {
		this.bill_street1 = bill_street1;
	}

	public String getBill_city() {
		return bill_city;
	}

	public void setBill_city(String bill_city) {
		this.bill_city = bill_city;
	}

	public String getBill_state() {
		return bill_state;
	}

	public void setBill_state(String bill_state) {
		this.bill_state = bill_state;
	}

	public String getBill_country() {
		return bill_country;
	}

	public void setBill_country(String bill_country) {
		this.bill_country = bill_country;
	}

	public int getBill_zipcode() {
		return bill_zipcode;
	}

	public void setBill_zipcode(int bill_zipcode) {
		this.bill_zipcode = bill_zipcode;
	}

	private String bill_country;
	
	private int bill_zipcode;

		
}
