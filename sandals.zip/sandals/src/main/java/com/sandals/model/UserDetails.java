package com.sandals.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class UserDetails {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	@Column(name="user_id")
	private int user_id;
	
	
	@Column(name="user_name")
	private String user_name;
	
	@Column(name="user_username")
	private String user_username;
	
	@Column(name="user_email")
	private String user_email;
	
	@Column(name="user_address")
	private String user_address;
	
	@Transient
	private String user_password;
	
	@Column(name="user_mobilenumber")
	private long user_mobilenumber;

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_username() {
		return user_username;
	}

	public void setUser_username(String user_username) {
		this.user_username = user_username;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getUser_address() {
		return user_address;
	}

	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public long getUser_mobilenumber() {
		return user_mobilenumber;
	}

	public void setUser_mobilenumber(long user_mobilenumber) {
		this.user_mobilenumber = user_mobilenumber;
	}

	
}
