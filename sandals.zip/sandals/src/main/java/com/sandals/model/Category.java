package com.sandals.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Table;

@Entity
//@Table(name="Category")
public class Category {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="cat_id")
	private int cat_id;
	
	@Column(name="cat_name")
	private String cat_name;
	
	
	
	public int getcat_id() {
		return cat_id;
	}


	public void setcat_id(int cat_id) {
		this.cat_id = cat_id;
	}


	public String getcat_name() {
		return cat_name;
	}


	public void setcat_name(String cat_name) {
		this.cat_name = cat_name;
	}


	public String getcat_desc() {
		return cat_desc;
	}


	public void setcat_desc(String cat_desc) {
		this.cat_desc = cat_desc;
	}


	@Column(name="cat_desc")
	private String cat_desc;
	
}