package com.sandals.Dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.Supplier;


@Repository
@Transactional
public class SupplierDAOImpl implements SupplierDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	



public void add(Supplier acmobj) {
	// TODO Auto-generated method stub
	
	   Session session=sessionFactory.openSession();
	   Transaction tx=session.getTransaction();
	   tx.begin();
	   session.save(acmobj);
	   
	   session.flush();
	   tx.commit();
	   session.close();
	
	
}



@SuppressWarnings("rawtypes")
public List getSupplier() {
	// TODO Auto-generated method stub
	Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	@SuppressWarnings("deprecation")
	List getSupplier=session.createQuery("from Supplier").list();
	tx.commit();
	session.close();
	return getSupplier;

}




public void EditSupplier(Supplier sandalentities) {
	// TODO Auto-generated method stub

	Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	Supplier s=(Supplier)session.get(Supplier.class,sandalentities.getSup_id());
	s.setSup_name(sandalentities.getSup_name());
	s.setSup_emailid(sandalentities.getSup_emailid());
	s.setSup_address(sandalentities.getSup_address());
	session.update(s);
	tx.commit();
	
	
	
}



public void delete(int sid) {
	// TODO Auto-generated method stub
	
	Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	Supplier dele=(Supplier)session.get(Supplier.class, sid);
	session.delete(dele);
	session.flush();
	tx.commit();
	session.close();
	
	
	
}



public Supplier EditSupplieredit(int sid) {
	// TODO Auto-generated method stub
	
	Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	Supplier edit=(Supplier)session.get(Supplier.class, sid);
	session.flush();
	tx.commit();
	session.close();
	return edit;
		

}

		
			
		
}
	
	
	
	
	
	

