package com.sandals.Dao;

import java.util.List;

import com.sandals.model.Products;

public interface ProductDAO {

	public void addProduct(Products apmobj);
	public String[] getCatSell();
	@SuppressWarnings("rawtypes")
	public List getProduct();
	public void DelProduct(int prod_id);
	public void EditProduct(Products pobj);
	public Products EditProduct(int prod_id);
	
	
	
	
}

