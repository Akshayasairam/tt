package com.sandals.Dao;
public interface Productsview {

	
	public String getallview();
	public String[] viewallprod(int prod_id);
	

}
