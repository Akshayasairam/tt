package com.sandals.Dao;

import java.util.List;

import com.sandals.model.UserDetails;

public interface RegisterUserCredDAO {
	
	public void AddUserDetails(UserDetails udcobj);
	@SuppressWarnings("rawtypes")
	public List getUserCred(); 

}
