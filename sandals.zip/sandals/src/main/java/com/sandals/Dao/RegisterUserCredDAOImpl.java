package com.sandals.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.UserCredentials;
import com.sandals.model.UserDetails;

@Repository
@Transactional
public class RegisterUserCredDAOImpl implements RegisterUserCredDAO{

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void AddUserDetails(UserDetails udcobj) {
		// TODO Auto-generated method stub
		
		UserCredentials uc=new UserCredentials();
		uc.setUser_name(udcobj.getUser_name());
		uc.setUser_password(udcobj.getUser_password());
		
		Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   session.save(udcobj);
		   session.save(uc);
		   session.flush();
		   tx.commit();
		   session.close();	
		
		
		
		
		
		
	}

	@SuppressWarnings("rawtypes")
	public List getUserCred() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   @SuppressWarnings("deprecation")
		List list=session.createQuery("from UserDetails").list();
		   
		   session.flush();
		   tx.commit();
		   session.close();
		
		return list;
	}

}
