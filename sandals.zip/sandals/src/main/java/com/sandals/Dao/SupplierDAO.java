package com.sandals.Dao;

import java.util.List;

import com.sandals.model.Supplier;

public interface SupplierDAO {
	
	
	 public void add(Supplier acmobj);
	 public void delete(int sid);
	 @SuppressWarnings("rawtypes")
	public List getSupplier();
	 public Supplier EditSupplieredit(int sid);
	 public void EditSupplier(Supplier acmobj);
}