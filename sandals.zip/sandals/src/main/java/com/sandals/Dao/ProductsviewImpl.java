package com.sandals.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.Category;
import com.sandals.model.Products;
import com.sandals.model.Supplier;
import com.google.gson.Gson;


@Repository
@Transactional
public class ProductsviewImpl implements Productsview {

	@Autowired
	private SessionFactory sessionFactory;

	
	

	
	public String getallview() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		@SuppressWarnings({ "rawtypes", "deprecation" })
		List listprod=session.createQuery("from Products").list();
		Gson gson=new Gson();
		String pv=gson.toJson(listprod);
		session.flush();
		tx.commit();
		session.close();
		
		return pv;
	}





	public String[] viewallprod(int prod_id) {
		// TODO Auto-generated method stub
		int cat_id,supp_id;
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Products c=(Products)session.get(Products.class, prod_id);
	    cat_id=c.getCat_id();
	    supp_id=c.getSupp_id();
	    Category d=(Category)session.get(Category.class, cat_id);
        Supplier e=(Supplier)session.get(Supplier.class, supp_id);		
	
		Gson gson=new Gson();
		String pd[]=new String[3];
		pd[0]=gson.toJson(c);
		pd[1]=gson.toJson(d);
		pd[2]=gson.toJson(e);
		session.flush();
		tx.commit();
		session.close();
		return pd;
	}


}
