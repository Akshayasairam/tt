package com.sandals.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.Products;
import com.google.gson.Gson;


@Repository
@Transactional

public class ProductDAOImpl implements ProductDAO{

	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void addProduct(Products sobj) {
		// TODO Auto-generated method stub

		   Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   session.save(sobj);
		   
		   session.flush();
		   tx.commit();
		   session.close();	
		
		
	}

	public String[] getCatSell() {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		@SuppressWarnings("rawtypes")
		List listcategory=session.createQuery("from Category").getResultList();
		@SuppressWarnings("rawtypes")
		List listsupply=session.createQuery("from Supplier").getResultList();
		
		Gson g=new Gson();
		String[] cat=new String[2];
		cat[0]=g.toJson(listcategory);
		cat[1]=g.toJson(listsupply);
		
	
		session.flush();	
		
		session.close();
		return cat;
	}
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public List getProduct() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List getProduct=session.createQuery("from Products").list();
		tx.commit();
		session.close();
		return getProduct;
	}
	public void DelProduct(int prod_id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Products p=(Products)session.get(Products.class, prod_id);
		session.delete(p);
		tx.commit();
		session.close();
		
		
		
	}

	public void EditProduct(Products pobj) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Products p=(Products)session.get(Products.class,pobj.getProd_id());
		p.setProd_name(pobj.getProd_name());
		p.setProd_desc(pobj.getProd_desc());
		p.setProd_price(pobj.getProd_price());
		p.setProd_quantity(pobj.getProd_quantity());
		session.update(p);
		tx.commit();
			
	}

	public Products EditProduct(int prod_id) {
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Products edit=(Products)session.get(Products.class, prod_id);
		session.flush();
		tx.commit();
		session.close();
		return edit;
		
		// TODO Auto-generated method stub
	}

}
