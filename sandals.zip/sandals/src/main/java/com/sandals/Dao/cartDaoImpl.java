package com.sandals.Dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.sandals.model.Cart;
import com.sandals.model.Products;

@Repository
public class cartDaoImpl implements cartDao {

	@Autowired
	SessionFactory sessionFactoryProducts;
	
	
	public List<Cart> addToCart(int pid, List<Cart> cartinfo,int qty) {
		// TODO Auto-generated method stub
		Products prod = new Products();
		Session session = sessionFactoryProducts.openSession();
		Query query = session.createQuery("FROM Products WHERE prod_id = :id");
		query.setParameter("id", pid);
		prod = (Products) query.getSingleResult();
		Cart cart = new Cart(prod,qty);
		cartinfo.add(cart);
		session.close();
		return cartinfo;
	}
	public String viewCart(List<Cart> cartinfo){
		// TODO Auto-generated method stub
		Gson gson = new Gson();
		String gsontojson = gson.toJson(cartinfo);
		return gsontojson;
	}
	public List<Cart> updateQty(int pid, List<Cart> cartinfo, int qty) {
		// TODO Auto-generated method stub
		for(Cart cinfo : cartinfo )
		{	
			if( cinfo.getC_pid() == pid)
			{
				cinfo.setQty(qty);
			}
		}
		return cartinfo;
	}
	public List<Cart> deleteFromCart(int pid, List<Cart> cartinfo) {
		// TODO Auto-generated method stub
		for(Cart cinfo : cartinfo )
		{	
			if( cinfo.getC_pid() == pid)
			{
				cartinfo.remove(cinfo);
				break;
			}
		}
		return cartinfo;
	}

}
