package com.sandals.Dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.BillingAddress;
import com.sandals.model.Card;


@Repository
@Transactional
public class BillingAddressDAOImpl implements BillingAddressDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public void add(BillingAddress bmpl) {
		
	   Session session=sessionFactory.openSession();
	   Transaction tx=session.getTransaction();
	   tx.begin();
	   session.save(bmpl);
	   
	   session.flush();
	   tx.commit();
	   session.close();
		
	}
	public void add1(Card cpl) {
		
		   Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   session.save(cpl);
		   
		   session.flush();
		   tx.commit();
		   session.close();
	}

	@SuppressWarnings("rawtypes")
	public List getBillingAddress(){
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		@SuppressWarnings("deprecation")
		List getBillingAddress=session.createQuery("from BillingAddress").list();
		tx.commit();
		session.close();
		return getBillingAddress;
	}
}