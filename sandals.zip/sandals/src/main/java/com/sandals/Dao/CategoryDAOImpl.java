package com.sandals.Dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sandals.model.Category;


@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	public void add(Category sandalentities) {
		
	   Session session=sessionFactory.openSession();
	   Transaction tx=session.getTransaction();
	   tx.begin();
	   session.save(sandalentities);
	   
	   session.flush();
	   tx.commit();
	   session.close();
		
	}



	@SuppressWarnings("rawtypes")
	public List getCategory(){
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		@SuppressWarnings("deprecation")
		List getCategory=session.createQuery("from Category").list();
		tx.commit();
		session.close();
		return getCategory;
	}



//		public void delete(Category acmobj)
//		{
//			Session session=sessionFactory.openSession();
//			Transaction tx=session.getTransaction();
//			tx.begin();
//			sessionFactory.getCurrentSession().delete(acmobj);
//			session.flush();
//			tx.commit();
//			session.close();
//			
//		}



		public void delete(int cid) {
			// TODO Auto-generated method stub
			Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			Category dele=(Category)session.get(Category.class, cid);
			session.delete(dele);
			session.flush();
			tx.commit();
			session.close();
			
		}
		public Category EditCategory(int cid){
			Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			Category edit=(Category)session.get(Category.class, cid);
			session.flush();
			tx.commit();
			session.close();
			return edit;
			
		}


public void EditCategory(Category sandalentities)
{
	Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	Category c=(Category)session.get(Category.class,sandalentities.getcat_id());
	c.setcat_name(sandalentities.getcat_name());
	c.setcat_desc(sandalentities.getcat_desc());
	session.update(c);
	tx.commit();
	
}

		
			
		
}
	
	
	
	
	
	

