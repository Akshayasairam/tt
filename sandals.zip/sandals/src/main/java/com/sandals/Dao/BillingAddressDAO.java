package com.sandals.Dao;

import com.sandals.model.BillingAddress;
import com.sandals.model.Card;
public interface BillingAddressDAO {

	public void add(BillingAddress bmpl);
	public void add1(Card cpl);
}
