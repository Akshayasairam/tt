package com.sandals.Dao;

import java.util.List;

import com.sandals.model.Category;

public interface CategoryDAO {
	 public void add(Category acmobj);
	 public void delete(int cid);
	 
	 
		@SuppressWarnings("rawtypes")
		public List getCategory();
		public Category EditCategory(int cid);
		public void EditCategory(Category sandalentities);
		


}