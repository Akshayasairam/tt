package com.sandals.controller;



import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sandals.Dao.CategoryDAO;
import com.sandals.model.Category;


@SuppressWarnings("unused")
@Controller
public class Categorycontroller {
	 @Autowired
	 CategoryDAO cdao;
	 
	 public String getdata(){
		 @SuppressWarnings("rawtypes")
		ArrayList list=(ArrayList)cdao.getCategory();
		 Gson gson= new Gson();
		 String jsonInString=gson.toJson(list);
		 return jsonInString;
	 }
	
	 
	 @RequestMapping("/admin.akc")
	 public String gotoadmin(){
		 
		 
		 return "Admin";
	 }
	 
	 
	/*@RequestMapping("/admi
	 * n.rkc")
	public String gotomanagecategory()
	{
		System.out.println("category");
		return "ManageCategory";
	}*/

	@RequestMapping(value="/admin.rkc",method=RequestMethod.GET)

	public ModelAndView addCategory(Model m){
		
		
		ModelAndView mv=new ModelAndView("AddCategory","category",new Category());
		
		
		return mv;
	}
	
	

	
@RequestMapping(value="/admin.rkc",method=RequestMethod.POST)
public ModelAndView addCategory(Category acmobj, Model m){
	
	
	cdao.add(acmobj);
	m.addAttribute("list",getdata());
	ModelAndView mv=new ModelAndView("CategorySuccess","category", new Category());
	
	return mv;
	
	
}
@RequestMapping(value="/admin.vkc")
public ModelAndView viewCategory(Category acmobj,Model m){
	
	m.addAttribute("list",getdata());
	ModelAndView mv=new ModelAndView("CategorySuccess","category", new Category());
	return mv;
	
}

@RequestMapping(value="/delCategory")
public ModelAndView delCategory(@RequestParam("id")int cid, Model m){
	
	
	cdao.delete(cid);

	m.addAttribute("list",getdata());
	ModelAndView mv=new ModelAndView("CategorySuccess","category", new Category());
	
	return mv;

}
@RequestMapping(value="/EditCategory")
public ModelAndView EditCategory(@RequestParam("id")int cid, Model m){
	Category obj=cdao.EditCategory(cid);
	m.addAttribute("editlist",obj);
	System.out.println("here i reached!!");
	ModelAndView mv=new ModelAndView("EditCategory","category", new Category());
	return mv;
	
}
@RequestMapping(value="/EditCategory", method=RequestMethod.POST)
public ModelAndView EditCategory(Category typeproduct,Model m)
{
	
	
	System.out.println("Im here");
	cdao.EditCategory(typeproduct);
	System.out.println("Im here");
	m.addAttribute("list",getdata());
	System.out.println("Im here");
	ModelAndView mv=new ModelAndView("CategorySuccess","category", new Category());
	System.out.println("Im here");
	return mv;
	
}




}
