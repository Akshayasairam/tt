package com.sandals.controller;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sandals.model.*;
@SuppressWarnings("unused")
@Controller
public class mappingcontroller {
	
	
@RequestMapping("/login.aks")
public String gotolog()
{
		System.out.println("Login");
		return "login";
		
		
}
	@RequestMapping(value="/login_session_attributes",method=RequestMethod.POST)
	public String logsucc(Model m){
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String uname=SecurityContextHolder.getContext().getAuthentication().getName();

		@SuppressWarnings("unchecked")
		Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder.getContext().getAuthentication().getAuthorities();
		String urlmapping="";
		String role="ROLE_USER";
		for (GrantedAuthority authority : authorities) 
		{
		  
		     if (authority.getAuthority().equals(role)) 
		     {
		    	
			 urlmapping="/prod.htm";
		    	 
		     }
		     else 
		     {
		    	
		    	 urlmapping="/admin.akc";
			
		    }
		     
		}
		return "redirect:"+urlmapping;
	}
	
	
	
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response)
	{
		Authentication auth= SecurityContextHolder.getContext().getAuthentication();
		if(auth!=null){
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "redirect:/";
	}
	
	
	
	
	@RequestMapping("/reg.htm")
	public String gotoreg()
	{
		System.out.println("Register");
		return "register";
	}
	
	
	
	@RequestMapping("/abtus.abc")
	public String gotoaboutus()
	{
		System.out.println("About Us");
		return "AboutUs";
	}
	
	
	
	@RequestMapping("/contact.acc")
	public String gotocontactus()
	{
		System.out.println("Contact Us");
		return "Contact";
	}
	
	
	
	
}
