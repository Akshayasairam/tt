package com.sandals.controller;



import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sandals.Dao.SupplierDAO;
import com.sandals.model.Supplier;


@Controller
public class Suppliercontroller {
	 @Autowired
	 SupplierDAO sdao;
	 
	 public String getdata(){
		 @SuppressWarnings("rawtypes")
		ArrayList list=(ArrayList)sdao.getSupplier();
		 Gson gson= new Gson();
		 String jsonInString=gson.toJson(list);
		 return jsonInString;
	 }
	
	 
	 @RequestMapping(value="/admin.addsupp",method=RequestMethod.GET)
	 public ModelAndView addSupply(Model m){
			System.out.println("reachd here");
			
			ModelAndView mv=new ModelAndView("Addsupply","supplier", new Supplier());
			System.out.println("reachd here");
			
			return mv;
}		
	
//	 @RequestMapping(value="/admin.addsupp")
//	 public String gotoAddsupp(){
//		 
//		 
//		 return "Addsupply";
//	 }
	 
	 
@RequestMapping(value="/admin.supplyadd",method=RequestMethod.POST)
public ModelAndView add(Supplier acmobj, Model m){
	
	
	sdao.add(acmobj);
	m.addAttribute("list",getdata());
	
	ModelAndView mv=new ModelAndView("SupplierSuccess","supplier", new Supplier());
	return mv;
	
}


@RequestMapping(value="/admin.supplyview")
public ModelAndView viewSupplier(Supplier acmobj,Model m){
	
	m.addAttribute("list",getdata());
	ModelAndView mv=new ModelAndView("SupplierSuccess","supplier", new Supplier());
	return mv;
	
}

@RequestMapping(value="/DelSup")
public ModelAndView delSupplier(@RequestParam("id")int sid, Model m){
	
	
	sdao.delete(sid);

	m.addAttribute("list",getdata());
	ModelAndView mv=new ModelAndView("SupplierSuccess","supplier", new Supplier());
	
	return mv;

}
@RequestMapping(value="/EditSup")
public ModelAndView EditSupplieredit(@RequestParam("id")int sid, Model m){
	
	System.out.println("hai");
	
	Supplier obj=sdao.EditSupplieredit(sid);
	System.out.println("hai");
	m.addAttribute("editlist1",obj);
	ModelAndView mv=new ModelAndView("EditSupply","supplier", new Supplier());
	return mv;
	
}
@RequestMapping(value="/EditSupplier", method=RequestMethod.POST)
public ModelAndView EditSupplier(Supplier typeproduct,Model m)
{
	
	
	
	sdao.EditSupplier(typeproduct);
	
	m.addAttribute("list",getdata());
	
	ModelAndView mv=new ModelAndView("SupplierSuccess","supplier", new Supplier());
	
	return mv;
	
}




}
