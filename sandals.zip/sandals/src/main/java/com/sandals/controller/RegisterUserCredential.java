package com.sandals.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sandals.Dao.RegisterUserCredDAO;
import com.sandals.model.UserDetails;

@Controller
public class RegisterUserCredential {
	

	
	@Autowired
	private RegisterUserCredDAO ruc;
	
	public String getUserCredential(){
		@SuppressWarnings("rawtypes")
		List list=ruc.getUserCred();
		Gson gson=new Gson();
		String jsonInString=gson.toJson(list);
		System.out.println(jsonInString);
		return jsonInString;
		
	}	
	
	
	@RequestMapping(value="/admin.userinfo")
	public ModelAndView gotouserinfo (Model m)
	{
	m.addAttribute("userdetailslist", getUserCredential());
	ModelAndView mv=new ModelAndView("ReguserSuccess");
	return mv;
	}
	
	
	
	
	
	
	@RequestMapping(value="/reguser.cred",method=RequestMethod.POST)
	public ModelAndView regusercred(UserDetails udobj, Model m){
		ruc.AddUserDetails(udobj);
		
	ModelAndView mv=new ModelAndView("success","udobj", new UserDetails());
	return mv;
	}
}
