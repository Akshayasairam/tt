package com.sandals.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sandals.Dao.cartDaoImpl;
import com.sandals.Dao.ProductDAOImpl;
import com.sandals.Dao.Productsview;
import com.sandals.model.Cart;
import com.sandals.model.Products;

@SuppressWarnings("unused")
@Controller
@SessionAttributes("cartinfo")
public class cartController {
	@Autowired
	cartDaoImpl cartdaoimpl;
	 @Autowired
	 ProductDAOImpl pdaoimpl;
		@Autowired
		private Productsview prdv;
	@RequestMapping("/addToCart-{pid}-Product-{qty}")
	public ModelAndView addToCart(@PathVariable("pid") int pid,@PathVariable("qty") int qty, @ModelAttribute("cartinfo")List<Cart> cartinfo,RedirectAttributes redirectAttributes, HttpSession session )
	{
		boolean add = true;
		
		for(Cart cinfo : cartinfo )
		{	
			if( cinfo.getC_pid() == pid)
			{
				add= false;
				break;
			}
		}
		if(add == true)
		{	
			
			cartinfo=cartdaoimpl.addToCart(pid,cartinfo,qty);
		}
		else
		{
			cartinfo=cartdaoimpl.updateQty(pid, cartinfo, qty);
		}
		
		redirectAttributes.addFlashAttribute("pList", pdaoimpl.getCatSell());
		redirectAttributes.addFlashAttribute("cList", cartdaoimpl.viewCart(cartinfo));
		redirectAttributes.addFlashAttribute("cartinfo", cartinfo);
		session.setAttribute("cart1", cartdaoimpl.viewCart(cartinfo));
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/footwear");
		return mv;
	}
	@RequestMapping("/delete-{pid}-Product")
	public ModelAndView deleteFromCart(@PathVariable("pid") int pid, @ModelAttribute("cartinfo")List<Cart> cartinfo,RedirectAttributes redirectAttributes,HttpSession session)
	{
		cartinfo=cartdaoimpl.deleteFromCart(pid, cartinfo);
		redirectAttributes.addFlashAttribute("pList", pdaoimpl.getCatSell());
		session.setAttribute("cart1", cartdaoimpl.viewCart(cartinfo));
		redirectAttributes.addFlashAttribute("cartinfo", cartinfo);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/footwear");
		return mv;
		
	}
	@RequestMapping("/footwear")
	public ModelAndView menu(Model model, HttpSession session)
	{
		model.addAttribute("pList", pdaoimpl.getCatSell());
	   
	    ModelAndView mv = new ModelAndView("Cart");		   
		return mv;
	}
	
	@RequestMapping(value="/prod.viewprod",method=RequestMethod.GET)
	public ModelAndView displayprodview(@RequestParam("id")int prod_id,Model m,HttpSession session){
	    
		System.out.println(prod_id);
		String pv1[]=prdv.viewallprod(prod_id);
	    m.addAttribute("productlist",pv1[0]);
	    m.addAttribute("categorylist",pv1[1]);
	    m.addAttribute("supplierlist",pv1[2]);
		if(session.getAttribute("cartinfo")== null ) {
	    	session.setAttribute("cart1", new ArrayList<Cart>());
	        m.addAttribute("cList", new ArrayList<Cart>());
	        session.setAttribute("cartinfo", new ArrayList<Cart>());
	    }
		ModelAndView mv=new ModelAndView("DisplayProducts");
		return mv;
	}
	
}
