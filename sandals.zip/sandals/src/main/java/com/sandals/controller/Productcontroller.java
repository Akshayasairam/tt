package com.sandals.controller;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sandals.Dao.ProductDAO;
import com.sandals.model.Products;
import com.sandals.model.Supplier;

@SuppressWarnings("unused")
@Controller
public class Productcontroller {

	@Autowired
	private ProductDAO spd;
	
	
	public String getData(){
		@SuppressWarnings("rawtypes")
		ArrayList list=(ArrayList)spd.getProduct();
		Gson gson=new Gson();
		String jsonInString=gson.toJson(list);
		
		return jsonInString;
		
		
	}
	
	
	@RequestMapping(value="/product.view")
	public ModelAndView gotoProd(Model m){
		
		m.addAttribute("product", getData());
		ModelAndView mv=new ModelAndView("ProductSuccess","prodobj",new Products());
		
		return mv;
		
	}
	
	
	@RequestMapping(value="/product.pro",method=RequestMethod.GET)
	public ModelAndView Product(Model m){
		
		String[] catselldetails=spd.getCatSell();
		System.out.println(catselldetails[0]);
		System.out.println(catselldetails[1]);
		m.addAttribute("categorylist",catselldetails[0]);
		m.addAttribute("supplierlist",catselldetails[1]);
		ModelAndView mv=new ModelAndView("AddProduct","acsobject",new Products());
		
		return mv;
	}
	
	@RequestMapping(value="/product.addproduct",method=RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute("acsobject")Products sobj,Model m) throws InterruptedException{
		System.out.println("Controller");
		spd.addProduct(sobj);
		
		String path="C:\\Users\\Akshaya Sairam\\Desktop\\DTworkspace\\sandals\\src\\main\\webapp\\resources\\images\\";
		path=path+String.valueOf(sobj.getProd_id()+".jpg");
		File f=new File(path);
		
		MultipartFile fileloc=sobj.getProd_image();
		
		if(!fileloc.isEmpty())	
		{
			try{
				byte[] bytes=fileloc.getBytes();
				FileOutputStream fos=new FileOutputStream(f);
				BufferedOutputStream bs=new BufferedOutputStream(fos);
				bs.write(bytes);
      			bs.close();
      			System.out.println("File Uploaded Successfully");
     			
				
			}
			
			catch(Exception e){
				
				System.out.println("File not uploaded error....");
			}
		}
		
		m.addAttribute("product", getData());
		ModelAndView mv=new ModelAndView("ProductSuccess","prodobj",new Products());
		
		
		
		Thread.sleep(7000);
		

	
		return mv;
	}
	
	@RequestMapping(value="/delProduct")
	public ModelAndView delProduct(@RequestParam("id")int pid, Model m){
		
		
		spd.DelProduct(pid);
		
		m.addAttribute("product", getData());
		ModelAndView mv=new ModelAndView("ProductSuccess","prodobj",new Products());
		

	
		return mv;
		
		
	}
	
	
	@RequestMapping(value="/EditProduct")
	public ModelAndView EditProductedit(@RequestParam("id")int pid, Model m){
		

		
		Products getdata=spd.EditProduct(pid);
		m.addAttribute("editprodlist",getdata);
		ModelAndView mv=new ModelAndView("EditProduct","product", new Products());
		return mv;
		
	}
	@RequestMapping(value="/EditProduct", method=RequestMethod.POST)
	public ModelAndView EditProduct(@ModelAttribute("editprodlist")Products typeproduct,Model m)
	{
		
		System.out.println();
		
		spd.EditProduct(typeproduct);
		
		
		
		m.addAttribute("product", getData());
		ModelAndView mv=new ModelAndView("ProductSuccess","prodobj",new Products());
		

	
		return mv;
		
}

}