package com.sandals.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sandals.Dao.Productsview;


@Controller
public class ViewController {

	@Autowired
	private Productsview prdv;
	
	
	@RequestMapping("/prod.htm")
	public ModelAndView getprodview(Model m, HttpSession session){
		
		String pv1=prdv.getallview();
		m.addAttribute("productlist",pv1);
		ModelAndView mv=new ModelAndView("ProductsviewSuccess");

		return mv;
	}

	
	
	
	
}
