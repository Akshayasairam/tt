package com.sandals.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.sandals.Dao.BillingAddressDAOImpl;
import com.sandals.model.BillingAddress;
import com.sandals.model.Card;


@Controller
public class BillingController {

	@Autowired
	BillingAddressDAOImpl ba;
	
	
	 public String getdata(){
		 @SuppressWarnings("rawtypes")
		ArrayList list=(ArrayList)ba.getBillingAddress();
		 Gson gson= new Gson();
		 String jsonInString=gson.toJson(list);
		 return jsonInString;
	 }
	 
	
	@RequestMapping(value="/bill.add")

	public ModelAndView addBilling(Model m){
		
		
		ModelAndView mv=new ModelAndView("AddBilling","billingaddress",new BillingAddress());
		
		
		return mv;
	}
	
	

	
@RequestMapping(value="/bill.order")
public ModelAndView add(@ModelAttribute BillingAddress bmpl, HttpSession session){
	
	
	
	session.setAttribute("address",bmpl);
	ModelAndView mv=new ModelAndView("Order");
	
	return mv;
	
}
@RequestMapping(value="/bill.final")
public ModelAndView billfinal(){
	ModelAndView mv=new ModelAndView("finalOrder");
	return mv;
}





@RequestMapping(value="/bill.card")
public ModelAndView add1(@ModelAttribute Card cpl, HttpSession session){
	
	
	
	session.setAttribute("card",cpl);
	ModelAndView mv=new ModelAndView("Card");
	
	return mv;
}
}
