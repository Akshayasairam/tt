package com.collaboration.web.service;

import java.util.List;

import com.collaboration.web.model.Blog;


public interface BlogService {

	List<Blog> findAllBlogs();

	Blog findById(long id);

	boolean isBlogExist(Blog blog);

	void saveBlog(Blog blog);

	void updateBlog(Blog currentblog);

	void deleteBlogById(Blog blog);

	
	

	
}
