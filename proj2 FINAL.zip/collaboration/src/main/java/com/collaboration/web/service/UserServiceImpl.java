package com.collaboration.web.service;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collaboration.web.model.User;
import com.collaboration.web.model.UserLog;



@Service("userService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	SessionFactory sessionFactory;

	    
	 
	    @SuppressWarnings("unchecked")
		public List<User> findAllUsers() {
	    	Session session=sessionFactory.openSession();
	    	List<User> list=new ArrayList<User>();
	    	list=session.createQuery("FROM Users").getResultList();
	    	session.close();
	        return list;
	    }
	     
	    public User findById(long id) {
	    	Session session=sessionFactory.openSession();
	    	User list=new User();
	    	Query query = session.createQuery("FROM Users WHERE id= :id");
	    	query.setParameter("id", id);
	    	list=(User) query.getSingleResult();
	    	session.close();
	        return list;
	    }
	     
	    public UserLog findByName(String name) {
	    	Session session=sessionFactory.openSession();
	    	UserLog list=new UserLog();
	    	Query query = session.createQuery("FROM UserLogs WHERE username= :username");
	    	query.setParameter("username", name);
	    	list=(UserLog) query.getSingleResult();
	    	session.close();
	        return list ;
	    }
	     
	    public void saveUser(User user) {
	    	Session session=sessionFactory.openSession();
	    	UserLog userlog=new UserLog();
	    	userlog.setUsername(user.getUsername());
	    	userlog.setPassword(user.getPassword());
	    	
			   Transaction tx=session.getTransaction();
			   tx.begin();
			   session.save(user);
			   session.save(userlog);
			   
			   session.flush();
			   tx.commit();
			   session.close();	
	    }
	 
	    public void updateUser(User user) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			session.update(user);
			tx.commit();
	    }
	 
	    public void deleteUserById(long id) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			User u=(User)session.get(User.class,id);
			session.delete(u);
			tx.commit();
			session.close();
	    }  
	       
	 
	    public boolean isUserExist(User user) {
	        return findByName(user.getUsername())!=null;
	    }
	     
	  
	 	public UserLog login(UserLog user) {
			// TODO Auto-generated method stub
			UserLog users= new UserLog();
			users=findByName(user.getUsername());
			if(users.getPassword().compareTo(user.getPassword()) ==0)
			{
				return users;
			}
			return null;
		}

		

		
		
	 
	}
	

