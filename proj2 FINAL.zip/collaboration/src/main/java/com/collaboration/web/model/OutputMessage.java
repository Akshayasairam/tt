package com.collaboration.web.model;

import java.util.Date;





public class OutputMessage extends Messaging {

	 private Date time;
	    
	    
		public OutputMessage(Messaging original, Date time) {
	        super(original.getId(),original.getValidUser(),original.getMessage());
	        this.time = time;
	    }
	    
	    public Date getTime() {
	        return time;
	    }
	    
	    public void setTime(Date time) {
	        this.time = time;
	    }
	}

