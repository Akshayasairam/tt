package com.collaboration.web.service;

import java.util.List;

import com.collaboration.web.model.Forum;

public interface ForumService {

	List<Forum> findAllForums();

	Forum findById(long id);

	boolean isForumExist(Forum forum);

	void saveForum(Forum forum);

	void updateForum(Forum currentforum);

	void deleteForumById(long id);

	void deleteAllForums();
}
