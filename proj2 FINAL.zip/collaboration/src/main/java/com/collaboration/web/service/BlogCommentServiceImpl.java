package com.collaboration.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collaboration.web.model.BlogComments;

@Service("BlogCommentService")
public class BlogCommentServiceImpl implements BlogCommentService{
	
	@Autowired
	SessionFactory sessionFactory;
	
	
	 
	public List<BlogComments> fetchComments(long id) {
    	Session session=sessionFactory.openSession();
    	List<BlogComments> list=new ArrayList<BlogComments>();
    	Query query=session.createQuery("FROM blogcomments WHERE blog_id = :id");
    	query.setParameter("id", id);
    	list = query.getResultList();
    	session.close();
        return list;
    }
	
	
     
   
	public void saveBlogComments(BlogComments comment) {
    	Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   comment.setComment_date(new Date());
		   tx.begin();
		   session.save(comment);
		   
		   session.flush();
		   tx.commit();
		   session.close();	
    }
 
    public void updateBlogComments(BlogComments comment) {
    	Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		session.update(comment);
		tx.commit();
    }
 

	public BlogComments findByBlog(long id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
    	BlogComments list=new BlogComments();
    	Query query = session.createQuery("FROM blogcomments WHERE id= :id");
    	query.setParameter("id", id);
    	list=(BlogComments) query.getSingleResult();
    	session.close();
        return list;
		
	}
	public void deleteBlogCommentsById(long id, long cid ) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Query query = session.createQuery("DELETE FROM blogcomments WHERE blog_id = :bid AND id= :cid");
		query.setParameter("bid", id);
		query.setParameter("cid", cid);
		query.executeUpdate();
		tx.commit();
		session.close();
	}  
}
