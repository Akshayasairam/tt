package com.collaboration.web.service;

import java.util.List;

import com.collaboration.web.model.ForumComments;

public interface ForumCommentService {

List<ForumComments> fetchComments(long id);
	
	void deleteForumCommentsById(long id,long cid);
	
	void updateForumComments(ForumComments comment);
	
	void saveForumComments(ForumComments comment);
	
	ForumComments findByForum(long id);
	
}
