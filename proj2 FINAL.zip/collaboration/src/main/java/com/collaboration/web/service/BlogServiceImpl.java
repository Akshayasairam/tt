package com.collaboration.web.service;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collaboration.web.model.Blog;



@Service("BlogService")
public class BlogServiceImpl implements BlogService{
	
	@Autowired
	SessionFactory sessionFactory;
	
	 
	 
	    @SuppressWarnings("unchecked")
		public List<Blog> findAllBlogs() {
	    	Session session=sessionFactory.openSession();
	    	List<Blog> list=new ArrayList<Blog>();
	    	list=session.createQuery("FROM blog").getResultList();
	    	session.close();
	        return list;
	    }
	     
	    public Blog findById(long id) {
	    	Session session=sessionFactory.openSession();
	    	Blog list=new Blog();
	    	Query query = session.createQuery("FROM blog WHERE id= :id");
	    	query.setParameter("id", id);
	    	list=(Blog) query.getSingleResult();
	    	session.close();
	        return list;
	    }
	     
	    public Blog findByName(String name) {
	        return null;
	    }
	     
	    public void saveBlog(Blog blog) {
	    	Session session=sessionFactory.openSession();
			   Transaction tx=session.getTransaction();

			   tx.begin();
			   session.save(blog);
			   
			   session.flush();
			   tx.commit();
			   session.close();	
	    }
	 
	    public void updateBlog(Blog blog) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			session.update(blog);
			tx.commit();
	    }
	 
	    public void deleteBlogById(long id) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			Blog u=(Blog)session.get(Blog.class,id);
			session.delete(u);
			tx.commit();
			session.close();
	    }  
	       
	 
	    public boolean isBlogExist(Blog blog) {
	        return findByName(blog.getBlogname())!=null;
	    }
	     
	   
		public void deleteBlogById(Blog blog) {
			// TODO Auto-generated method stub
			Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			session.delete(blog);
			tx.commit();
			session.close();
		}

		
	    
	}
	

