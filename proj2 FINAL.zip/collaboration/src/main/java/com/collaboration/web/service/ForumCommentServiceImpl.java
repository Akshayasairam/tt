package com.collaboration.web.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collaboration.web.model.ForumComments;

@Service("ForumCommentService")
public class ForumCommentServiceImpl implements ForumCommentService{
	
	@Autowired
	SessionFactory sessionFactory;
	
	
	 
	public List<ForumComments> fetchComments(long id) {
    	Session session=sessionFactory.openSession();
    	List<ForumComments> list=new ArrayList<ForumComments>();
    	Query query=session.createQuery("FROM forumcomments WHERE forum_id = :id");
    	query.setParameter("id", id);
    	list = query.getResultList();
    	session.close();
        return list;
    }
	
	
     
   
	public void saveForumComments(ForumComments comment) {
    	Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   comment.setComment_date(new Date());
		   tx.begin();
		   session.save(comment);
		   
		   session.flush();
		   tx.commit();
		   session.close();	
    }
 
    public void updateForumComments(ForumComments comment) {
    	Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		session.update(comment);
		tx.commit();
    }
 

	public ForumComments findByForum(long id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
    	ForumComments list=new ForumComments();
    	Query query = session.createQuery("FROM forumcomments WHERE id= :id");
    	query.setParameter("id", id);
    	list=(ForumComments) query.getSingleResult();
    	session.close();
        return list;
		
	}
	public void deleteForumCommentsById(long id, long cid ) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Query query = session.createQuery("DELETE FROM forumcomments WHERE forum_id = :bid AND id= :cid");
		query.setParameter("bid", id);
		query.setParameter("cid", cid);
		query.executeUpdate();
		tx.commit();
		session.close();
	}  
}
