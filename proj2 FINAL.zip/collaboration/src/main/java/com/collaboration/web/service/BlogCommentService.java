package com.collaboration.web.service;

import java.util.List;

import com.collaboration.web.model.BlogComments;

public interface BlogCommentService {

List<BlogComments> fetchComments(long id);
	
	void deleteBlogCommentsById(long id,long cid);
	
	void updateBlogComments(BlogComments comment);
	
	void saveBlogComments(BlogComments comment);
	
	BlogComments findByBlog(long id);
	
}
