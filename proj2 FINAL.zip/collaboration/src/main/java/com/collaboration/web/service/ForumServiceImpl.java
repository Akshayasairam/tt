package com.collaboration.web.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.collaboration.web.model.Forum;

@Service("ForumService")
public class ForumServiceImpl implements ForumService {

	@Autowired
	SessionFactory sessionFactory;
	@SuppressWarnings("unused")
	private static final AtomicLong counter = new AtomicLong();
	     
	    private static List<Forum> forums;
	     
	    
	 
	    @SuppressWarnings("unchecked")
		public List<Forum> findAllForums() {
	    	Session session=sessionFactory.openSession();
	    	List<Forum> list=new ArrayList<Forum>();
	    	list=session.createQuery("FROM forum").getResultList();
	    	session.close();
	        return list;
	    }
	     
	    public Forum findById(long id) {
	    	Session session=sessionFactory.openSession();
	    	Forum list=new Forum();
	    	Query query = session.createQuery("FROM forum WHERE id= :id");
	    	query.setParameter("id", id);
	    	list=(Forum) query.getSingleResult();
	    	session.close();
	        return list;
	    }
	     
	    public Forum findByName(String name) {
	        return null;
	    }
	     
	    public void saveForum(Forum forum) {
	    	Session session=sessionFactory.openSession();
			   Transaction tx=session.getTransaction();
			   
			   tx.begin();
			   session.save(forum);
			   
			   session.flush();
			   tx.commit();
			   session.close();	
	    }
	 
	    public void updateForum(Forum forum) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			session.update(forum);
			tx.commit();
	    }
	 
	    public void deleteForumById(long id) {
	    	Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			Forum u=(Forum)session.get(Forum.class,id);
			session.delete(u);
			tx.commit();
			session.close();
	    }  
	       
	 
	    public boolean isForumExist(Forum forum) {
	        return findByName(forum.getForumname())!=null;
	    }
	     
	    public void deleteAllForums(){
	        forums.clear();
	    }
	 
	    @SuppressWarnings("unused")
		private static List<Forum> populateDummyForums(){
	        List<Forum> forums = new ArrayList<Forum>();
	        forums.add(new Forum());
	        forums.add(new Forum());
	        forums.add(new Forum());
	        return forums;
	    }

		
	 
}
