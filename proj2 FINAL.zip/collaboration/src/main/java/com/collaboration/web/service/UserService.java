package com.collaboration.web.service;

import java.util.List;

import com.collaboration.web.model.User;
import com.collaboration.web.model.UserLog;

public interface UserService {

	List<User> findAllUsers();

	User findById(long id);
	
	UserLog findByName(String name);

	boolean isUserExist(User user);

	void saveUser(User user);

	void updateUser(User currentUser);

	void deleteUserById(long id);
	
	UserLog login(UserLog user);
	
	

	

	
}
