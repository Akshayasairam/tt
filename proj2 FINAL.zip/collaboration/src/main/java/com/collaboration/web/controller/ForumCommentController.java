package com.collaboration.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.collaboration.web.model.ForumComments;
import com.collaboration.web.service.ForumCommentService;


@RestController
public class ForumCommentController {

	
	@Autowired
	ForumCommentService forumcommentService;
	
	
	@RequestMapping(value="/forum/{id}/comm/", method= RequestMethod.GET)
	public ResponseEntity<List<ForumComments>> listAllForumComments(@PathVariable long id)
	{
		List<ForumComments> comment=forumcommentService.fetchComments(id);
		
		if(comment.isEmpty()){
			return new ResponseEntity<List<ForumComments>>(comment, HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<ForumComments>>(comment, HttpStatus.OK);
		}
	
	
	@RequestMapping(value = "/forum/{id}/comm/", method = RequestMethod.POST)
	public ResponseEntity<Void> createForumComments(@RequestBody ForumComments comment, @PathVariable long id) {
		comment.setForum_id(id);
	    forumcommentService.saveForumComments(comment);

	   
	    return new ResponseEntity<Void>(HttpStatus.CREATED);
	} 
	  
	
	@RequestMapping(value = "/forum/{bid}/comm/{cid}", method = RequestMethod.PUT)
	public ResponseEntity<ForumComments> updateForumComments(@PathVariable("bid") long bid,@PathVariable("cid") long cid, @RequestBody ForumComments comment) {

	    comment.setId(cid);
	    forumcommentService.updateForumComments(comment);
	    return new ResponseEntity<ForumComments>(comment, HttpStatus.OK);
	}

	@RequestMapping(value = "/forum/{id}/comm/{cid}", method = RequestMethod.DELETE)
	public ResponseEntity<ForumComments> deleteForumComments(@PathVariable("id") long id, @PathVariable("cid") long cid) {
	    System.out.println("Fetching & Deleting Forum with id " + id);



	    forumcommentService.deleteForumCommentsById(id,cid);
	    return new ResponseEntity<ForumComments>(HttpStatus.OK);
	}

}
