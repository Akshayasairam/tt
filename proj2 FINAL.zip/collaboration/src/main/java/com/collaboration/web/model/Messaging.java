package com.collaboration.web.model;

public class Messaging {

	private String message;
	  private int id;
	  private String validUser;
	  
	  public Messaging() {
		    
	  }
	  
	  public Messaging(int id,String validUser, String message) {
	    this.id = id;
	    this.message = message;
	    this.validUser=validUser;
	    System.out.println(validUser);
	  }
	  
	public String getValidUser() {
		return validUser;
	}

	public void setValidUser(String validUser) {
		this.validUser = validUser;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
