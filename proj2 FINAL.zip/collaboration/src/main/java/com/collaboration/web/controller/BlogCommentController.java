package com.collaboration.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.collaboration.web.model.BlogComments;
import com.collaboration.web.service.BlogCommentService;


@RestController
public class BlogCommentController {

	
	@Autowired
	BlogCommentService blogcommentService;
	
	
	@RequestMapping(value="/blog/{id}/comm/", method= RequestMethod.GET)
	public ResponseEntity<List<BlogComments>> listAllBlogComments(@PathVariable long id)
	{
		List<BlogComments> comment=blogcommentService.fetchComments(id);
		
		if(comment.isEmpty()){
			return new ResponseEntity<List<BlogComments>>(comment, HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<BlogComments>>(comment, HttpStatus.OK);
		}
	
	
	@RequestMapping(value = "/blog/{id}/comm/", method = RequestMethod.POST)
	public ResponseEntity<Void> createBlogComments(@RequestBody BlogComments comment, @PathVariable long id) {
		comment.setBlog_id(id);
	    blogcommentService.saveBlogComments(comment);

	   
	    return new ResponseEntity<Void>(HttpStatus.CREATED);
	} 
	  
	
	@RequestMapping(value = "/blog/{bid}/comm/{cid}", method = RequestMethod.PUT)
	public ResponseEntity<BlogComments> updateBlogComments(@PathVariable("bid") long bid,@PathVariable("cid") long cid, @RequestBody BlogComments comment) {

	    comment.setId(cid);
	    blogcommentService.updateBlogComments(comment);
	    return new ResponseEntity<BlogComments>(comment, HttpStatus.OK);
	}

	@RequestMapping(value = "/blog/{id}/comm/{cid}", method = RequestMethod.DELETE)
	public ResponseEntity<BlogComments> deleteBlogComments(@PathVariable("id") long id, @PathVariable("cid") long cid) {
	    System.out.println("Fetching & Deleting Blog with id " + id);



	    blogcommentService.deleteBlogCommentsById(id,cid);
	    return new ResponseEntity<BlogComments>(HttpStatus.OK);
	}

}
