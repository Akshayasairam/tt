'use strict';

angular.module('myApp').factory('Loginservice',['$http','$q' ,function($http,$q){

	var REST_SERVICE_URI='http://localhost:9080/collaboration/login/'
		
var factory= {
Login : Login
}; 
	return factory;
	
	
	function Login(user)
	{
		var deferred=$q.defer();
		
		$http.post(REST_SERVICE_URI, user)
		.then(
				function(response){
				deferred.resolve(response.data);
				},
				
				function(errResponse){
				console.error('error');
				deferred.reject(errResponse);
				}
				
		     );
		return deferred.promise;
		
};
}]);