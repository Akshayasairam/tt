'use strict';

angular.module('myApp').factory('blogCommentService',['$http','$q' ,function($http,$q){

	var REST_SERVICE_URI='http://localhost:9080/collaboration/blog/'
		
var factory= {
			fetchBlog : fetchBlog,
			fetchAllBlogComments: fetchAllBlogComments,
			createAllBlogComments : createAllBlogComments,
			updateAllBlogComments : updateAllBlogComments,
			deleteAllBlogComments : deleteAllBlogComments
			
	};
return factory;


function fetchBlog(id)
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI+id,id)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
}

function fetchAllBlogComments(id)
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI+id+'/comm/')
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
}

function createAllBlogComments(id,comments)
{
	var deferred=$q.defer();
	
	$http.post(REST_SERVICE_URI+id+'/comm/',comments)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in creation');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;		
}	

function updateAllBlogComments(comments, id) {
    var deferred = $q.defer();
    $http.put(REST_SERVICE_URI+comments.blog_id+'/comm/'+id, comments)
        .then(
        function (response) {
            deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while updating User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}
	
function deleteAllBlogComments(bid,cid) {
    var deferred = $q.defer();
    $http.delete(REST_SERVICE_URI+bid+'/comm/'+cid)
        .then(
        function (response) {
        	deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while deleting User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}

}]);