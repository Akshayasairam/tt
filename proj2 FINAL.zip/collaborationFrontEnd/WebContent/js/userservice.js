'use strict';

angular.module('myApp').factory('userservice',['$http','$q' ,function($http,$q){

	var REST_SERVICE_URI='http://localhost:9080/collaboration/user/'
		
var factory= {
			fetchAllUsers : fetchAllUsers,
			createAllUser : createAllUser,
			updateAllUser : updateAllUser,
			deleteAllUser : deleteAllUser
	};
return factory;

function fetchAllUsers()
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
	
}
	
function createAllUser(user)
{
	var deferred=$q.defer();
	
	$http.post(REST_SERVICE_URI,user)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in creation');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;		
}	

function updateAllUser(user, id) {
    var deferred = $q.defer();
    $http.put(REST_SERVICE_URI+id, user)
        .then(
        function (response) {
            deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while updating User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}
	
function deleteAllUser(id) {
    var deferred = $q.defer();
    $http.delete(REST_SERVICE_URI+id)
        .then(
        function (response) {
        	deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while deleting User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}

		
}]);
