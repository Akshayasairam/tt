'use strict';

angular.module('myApp').controller('Logincontroller',['$scope','$route','$cookies','$location','Loginservice', function($scope,$route,$cookies,$location, Loginservice)
  {                                                  
 var sr=this;
sr.user={id:null, username:'',password:''};
sr.users=[];
sr.validUser=$cookies.get('validUser');
sr.showlogout=showlogout;

sr.submit= submit;
sr.logout= logout;


function Login(user){
	  Loginservice.Login(user)
	  .then(
			  function(d){
				  sr.users=d;
				  $cookies.put('validUser',sr.users.username);
				  $location.path('/signin/');
				  window.location.reload();
			  },
	function(errResponse){
		console.error('error while creating');
	}
	  );
}

function showlogout(){
	console.log('validUser :',sr.validUser);
	if (typeof sr.validUser !== "undefined")
		{
		return true;

		}
	return false;
}


function submit(){
	Login(sr.user);
}

function logout(){
	$cookies.remove('validUser');
	 window.location.reload();


}

  }]);
