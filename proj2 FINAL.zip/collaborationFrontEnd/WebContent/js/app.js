'use strict';
 

var app=angular.module('myApp',['ngRoute','ngCookies']);

app.config(function($routeProvider,$locationProvider){
	console.log('entering configuration')
	$routeProvider
	.when('/',{
	templateUrl:'_user/LoginAndRegister.html'
	})
	
	.when('/login',{
	templateUrl:'_user/LoginAndRegister.html'
	})
	
	.when('/signin',{
	templateUrl:'Views/Nav.html'
	})
	
	.when('/blog',{
	templateUrl:'Views/Blog.html'
	})
	
	.when('/blog/:id',{
	templateUrl:'Views/BlogComments.html'
	})
	
	
	.when('/chat',{
	templateUrl:'Views/Chat.html'
	})
	
	.when('/forum',{
	templateUrl:'Views/Forum.html'
	})
	
	.when('/forum/:id',{
	templateUrl:'Views/ForumComments.html'
	})
	
	.when('/user',{
	templateUrl:'Views/User.html'
	})
	});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);
