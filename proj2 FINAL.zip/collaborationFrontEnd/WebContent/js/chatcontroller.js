angular.module("myApp").controller("chatcontroller", function($scope,$cookies, chatservice) {
  $scope.messages = [];
  $scope.message = "";
  $scope.max = 140;
  $scope.validUser=$cookies.get('validUser');
  $scope.user= function(correctUser){
	  document.getElementById("user").className="";
  
	  if($scope.validUser != correctUser){
		  document.getElementById("user").className="odd";
	  }
	  else{
		  document.getElementById("user").className="even";
	  }
  }
  

  $scope.addMessage = function() {
    chatservice.send($scope.validUser,$scope.message);
    $scope.message = "";
  };

  chatservice.receive().then(null, null, function(message) {
    $scope.messages.push(message);
  });
});