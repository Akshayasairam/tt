'use strict';

angular.module('myApp').controller('blogcontroller',['$scope','$location','$route','$cookies', 'blogservice', function($scope,$location,$route,$cookies, blogservice)
  {                                                  
 var br=this;
br.blog={id:null, Blogname:'',content:'',heading:''};
br.blogs=[];
br.validUser=$cookies.get('validUser');

br.submit= submit;
br.remove= remove;
br.edit=edit;
br.open=open;

fetchAllBlogs();

function fetchAllBlogs(){
	blogservice.fetchAllBlogs()
	.then(
		function(m){
			br.blogs= m;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
}
                                                     
  function createAllBlog(blog){
	  blogservice.createAllBlog(blog)
	  .then(
	fetchAllBlogs,
	function(errResponse){
		console.error('error while creating');
	}
	  );
  }                                                 
       
  function updateAllBlog(blog, id){
      blogservice.updateAllBlog(blog, id)
          .then(
          fetchAllBlogs,
          function(errResponse){
        	 
              console.error('Error while updating Blog');
             
          }
      );
  }
  

  function deleteAllBlog(id){
      blogservice.deleteAllBlog(id)
          .then(
          fetchAllBlogs,
          function(errResponse){
              console.error('Error while deleting Blog');
          }
      );
  }

 function submit(){
	 if(br.blog.id===null)
		 {
		 console.log('create blog', br.blog);
		 createAllBlog(br.blog);
		 window.location.reload();
		 }
	 else{
		 updateAllBlog(br.blog, br.blog.id);
		 console.log('updating blog',br.blog.id);
		 window.location.reload();
	 }
	 
 }                                                    
 function remove(id){
     console.log('id to be deleted', id);
     if(br.blog.id === id) {//clean form if the blog to be deleted is shown there.
         reset();
         
     }
     deleteAllBlog(id);
     if(validUser != blogs.username){
     	return false;
     }
     return true;
  
 }  
 
 
 function edit(id){
	 
     console.log('id to be edited', id);
     for(var i = 0; i < br.blogs.length; i++){
         if(br.blogs[i].id === id) {
             br.blog = angular.copy(br.blogs[i]);
            
         }
     }
        if(validUser != blogs.username){
        	return false;
        }
        return true;
     
 }
 
 function open(id){
	 $location.path('/blog/'+id);
 }
                                                     
}]);