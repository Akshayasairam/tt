'use strict';

angular.module('myApp').controller('usercontroller',['$scope','$http', 'userservice', function($scope,$http, userservice)
  {                                                  
 var sr=this;
sr.user={id:null, username:'',address:'',email:''};
sr.users=[];

sr.submit= submit;
sr.remove= remove;
sr.edit=edit;
sr.register=register;

fetchAllUsers();

function fetchAllUsers(){
	userservice.fetchAllUsers()
	.then(
		function(d){
			sr.users= d;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
}
                                                     
  function createAllUser(user){
	  userservice.createAllUser(user)
	  .then(
	fetchAllUsers,
	function(errResponse){
		console.error('error while creating');
	}
	  );
	  
	  var file = $scope.myFile;
		/* console.log('file is ' );
		console.dir(file);*/
		var uploadUrl = "http://localhost:9080/collaboration/user/";
		var fd = new FormData();
		fd.append('file', file);
		fd.append('user',angular.toJson($scope.user,true));
		console.log('Scope of user',sr.user.username);
		$http.post(uploadUrl+sr.user.username, fd, {
		transformRequest : angular.identity,
		headers : {
		'Content-Type' : undefined
		}
		}).success(function() {
		console.log('success');
		}).error(function() {
		console.log('error');
		});
  }                                                 
       
  function updateAllUser(user, id){
      userservice.updateAllUser(user, id)
          .then(
          fetchAllUsers,
          function(errResponse){
              console.error('Error while updating User');
          }
      );
  }
  

  function deleteAllUser(id){
      userservice.deleteAllUser(id)
          .then(
          fetchAllUsers,
          function(errResponse){
              console.error('Error while deleting User');
          }
      );
  }

 function submit(){
	 if(sr.user.id===null)
		 {
		 console.log('create user', sr.user);
		 createAllUser(sr.user);
		 }
	 else{
		 updateAllUser(sr.user, sr.user.id);
		 console.log('updating user',sr.user.id);
	 }
	 
 }                                                    
 function remove(id){
     console.log('id to be deleted', id);
     if(sr.user.id === id) {//clean form if the user to be deleted is shown there.
         reset();
     }
     deleteAllUser(id);
 }  
 
 function edit(id){
     console.log('id to be edited', id);
     for(var i = 0; i < sr.users.length; i++){
         if(sr.users[i].id === id) {
             sr.user = angular.copy(sr.users[i]);
             
         }
     }
 }
   
 function register(){
	 createAllUser(sr.user);
 }
}]);