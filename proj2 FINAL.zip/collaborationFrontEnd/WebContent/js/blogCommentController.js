'use strict';

angular.module('myApp').controller('blogCommentController',['$scope','$route','$location','$routeParams','blogCommentService', function($scope,$route,$location,$routeParams, blogCommentService)
  {                                                  
 var br=this;
br.blogComments={id:null,blog_id:null, name:'',comments:'',comment_date:''};
br.blogsComment=[];
br.blogs=[];
br.id=$routeParams.id;
br.submit=submit;
br.remove= remove;
br.edit=edit;
br.currentid=null;

fetchBlog(br.id);


function fetchBlog(id){
	blogCommentService.fetchBlog(id)
	.then(
		function(m){
			br.blogs= m;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
	blogCommentService.fetchAllBlogComments(id)
	.then(
		function(o){
			br.blogsComment= o;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
}
function createAllBlogComments(id,comments){
		
	  blogCommentService.createAllBlogComments(id,comments)
	  .then(null,
	function(errResponse){
		console.error('error while creating');
	}
	  );
}                                                 
     
function updateAllBlogComments(blogcomments, id){
	blogcomments.blog_id = br.id;
    blogCommentService.updateAllBlogComments(blogcomments, id)
        .then(null,
        function(errResponse){
            console.error('Error while updating Blog');
        }
    );
}


function deleteAllBlogComments(bid,cid){
    blogCommentService.deleteAllBlogComments(bid,cid)
        .then(
        null,
        function(errResponse){
            console.error('Error while deleting Blog');
        }
    );
}

function submit()
{
	console.log('id :',br.currentid);
	
	if(br.blogComments.id===null){
		createAllBlogComments(br.id,br.blogComments);
		window.location.reload();
	}
	else{
		updateAllBlogComments(br.blogComments, br.blogComments.id);
		window.location.reload();
	}
}

function remove(id){
    console.log('id to be deleted', id);
    if(br.blogComments.id === id) {//clean form if the blog to be deleted is shown there.
        reset();
       
    }
    deleteAllBlogComments(br.id,id);
    window.location.reload();
}  


function edit(id){
    console.log('id to be edited', id);
    for(var i = 0; i < br.blogsComment.length; i++){
        if(br.blogsComment[i].id === id) {
            br.blogComments = angular.copy(br.blogsComment[i]);
//            window.location.reload();
        }
    }
}

}]);