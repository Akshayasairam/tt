'use strict';

angular.module('myApp').controller('forumCommentController',['$scope','$route','$location','$routeParams','forumCommentService', function($scope,$route,$location,$routeParams, forumCommentService)
  {                                                  
 var br=this;
br.forumComments={id:null,forum_id:null, name:'',comments:'',comment_date:''};
br.forumsComment=[];
br.forums=[];
br.id=$routeParams.id;
br.submit=submit;
br.remove= remove;
br.edit=edit;
br.currentid=null;

fetchForum(br.id);


function fetchForum(id){
	forumCommentService.fetchForum(id)
	.then(
		function(m){
			br.forums= m;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
	forumCommentService.fetchAllForumComments(id)
	.then(
		function(o){
			br.forumsComment= o;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
}
function createAllForumComments(id,comments){
		
	  forumCommentService.createAllForumComments(id,comments)
	  .then(null,
	function(errResponse){
		console.error('error while creating');
	}
	  );
}                                                 
     
function updateAllForumComments(forumcomments, id){
	forumcomments.forum_id = br.id;
    forumCommentService.updateAllForumComments(forumcomments, id)
        .then(null,
        function(errResponse){
            console.error('Error while updating Forum');
        }
    );
}


function deleteAllForumComments(bid,cid){
    forumCommentService.deleteAllForumComments(bid,cid)
        .then(
        null,
        function(errResponse){
            console.error('Error while deleting Forum');
        }
    );
}

function submit()
{
	console.log('id :',br.currentid);
	
	if(br.forumComments.id===null){
		createAllForumComments(br.id,br.forumComments);
		$route.reload();
	}
	else{
		updateAllForumComments(br.forumComments, br.forumComments.id);
		
	}
}

function remove(id){
    console.log('id to be deleted', id);
    if(br.forumComments.id === id) {//clean form if the forum to be deleted is shown there.
        reset();
       
    }
    deleteAllForumComments(br.id,id);
    
}  


function edit(id){
    console.log('id to be edited', id);
    for(var i = 0; i < br.forumsComment.length; i++){
        if(br.forumsComment[i].id === id) {
            br.forumComments = angular.copy(br.forumsComment[i]);
            
        }
    }
}

}]);