'use strict';

angular.module('myApp').factory('forumCommentService',['$http','$q' ,function($http,$q){

	var REST_SERVICE_URI='http://localhost:9080/collaboration/forum/'
		
var factory= {
			fetchForum : fetchForum,
			fetchAllForumComments: fetchAllForumComments,
			createAllForumComments : createAllForumComments,
			updateAllForumComments : updateAllForumComments,
			deleteAllForumComments : deleteAllForumComments
			
	};
return factory;


function fetchForum(id)
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI+id,id)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
}

function fetchAllForumComments(id)
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI+id+'/comm/')
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
}

function createAllForumComments(id,comments)
{
	var deferred=$q.defer();
	
	$http.post(REST_SERVICE_URI+id+'/comm/',comments)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in creation');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;		
}	

function updateAllForumComments(comments, id) {
    var deferred = $q.defer();
    $http.put(REST_SERVICE_URI+comments.forum_id+'/comm/'+id, comments)
        .then(
        function (response) {
            deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while updating User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}
	
function deleteAllForumComments(bid,cid) {
    var deferred = $q.defer();
    $http.delete(REST_SERVICE_URI+bid+'/comm/'+cid)
        .then(
        function (response) {
        	deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while deleting User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}

}]);