'use strict';

angular.module('myApp').factory('blogservice',['$http','$q' ,function($http,$q){

	var REST_SERVICE_URI='http://localhost:9080/collaboration/blog/'
		
var factory= {
			fetchAllBlogs : fetchAllBlogs,
			createAllBlog : createAllBlog,
			updateAllBlog : updateAllBlog,
			deleteAllBlog : deleteAllBlog
	};
return factory;

function fetchAllBlogs()
{
	var deferred=$q.defer();
	
	$http.get(REST_SERVICE_URI)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in fetching');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;
	
}
	
function createAllBlog(blog)
{
	var deferred=$q.defer();
	
	$http.post(REST_SERVICE_URI,blog)
	.then(
			function(response){
			deferred.resolve(response.data);
			},
			
			function(errResponse){
			console.error('error in creation');
			deferred.reject(errResponse);
			}
			
	     );
	return deferred.promise;		
}	

function updateAllBlog(blog, id) {
    var deferred = $q.defer();
    $http.put(REST_SERVICE_URI+id, blog)
        .then(
        function (response) {
            deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while updating User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}
	
function deleteAllBlog(id) {
    var deferred = $q.defer();
    $http.delete(REST_SERVICE_URI+id)
        .then(
        function (response) {
        	deferred.resolve(response.data);
        },
        function(errResponse){
            console.error('Error while deleting User');
            deferred.reject(errResponse);
        }
    );
    return deferred.promise;
}

		
}]);
