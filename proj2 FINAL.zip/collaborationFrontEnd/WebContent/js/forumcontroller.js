'use strict';

angular.module('myApp').controller('forumcontroller',['$scope','$location', 'forumservice', function($scope,$location, forumservice)
  {                                                  
 var fr=this;
fr.forum={id:null, Forumname:'',content:'',heading:''};
fr.forums=[];

fr.submit= submit;
fr.remove= remove;
fr.edit=edit;
fr.open=open;

fetchAllForums();

function fetchAllForums(){
	forumservice.fetchAllForums()
	.then(
		function(m){
			fr.forums= m;
		},
		function(errResponse){
			console.error('error');
			
		}
	);
}
                                                     
  function createAllForum(forum){
	  forumservice.createAllForum(forum)
	  .then(
	fetchAllForums,
	function(errResponse){
		console.error('error while creating');
	}
	  );
  }                                                 
       
  function updateAllForum(forum, id){
      forumservice.updateAllForum(forum, id)
          .then(
          fetchAllForums,
          function(errResponse){
              console.error('Error while updating Forum');
          }
      );
  }
  

  function deleteAllForum(id){
      forumservice.deleteAllForum(id)
          .then(
          fetchAllForums,
          function(errResponse){
              console.error('Error while deleting Forum');
          }
      );
  }

 function submit(){
	 if(fr.forum.id===null)
		 {
		 console.log('create forum', fr.forum);
		 createAllForum(fr.forum);
		 
		 }
	 else{
		 updateAllForum(fr.forum, fr.forum.id);
		 console.log('updating forum',fr.forum.id);
		 window.location.reload();
	 }
	 
 }                                                    
 function remove(id){
     console.log('id to be deleted', id);
     if(fr.forum.id === id) {//clean form if the forum to be deleted is shown there.
         reset();
         window.location.reload();
     }
     deleteAllForum(id);
 }  
 
 function edit(id){
     console.log('id to be edited', id);
     for(var i = 0; i < fr.forums.length; i++){
         if(fr.forums[i].id === id) {
             fr.forum = angular.copy(fr.forums[i]);
             
             
         }
     }
 }
 
 function open(id){
	 $location.path('/forum/'+id);
 }
                                                     
}]);